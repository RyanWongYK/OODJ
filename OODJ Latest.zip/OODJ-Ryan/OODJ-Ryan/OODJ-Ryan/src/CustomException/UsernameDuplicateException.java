
package CustomException;

public class UsernameDuplicateException extends RuntimeException{
    @Override
    public String getMessage(){
        return "Username duplicate.";
    }
    
}
