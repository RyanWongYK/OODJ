
package CustomException;

public class UserDuplicateException extends RuntimeException{
    @Override
    public String getMessage(){
        return "User duplicate.";
    }
}
